﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using System.IO;
using System.Data.SQLite;

namespace WpfApplication2
{
    [Serializable()]
    public sealed class NumeroCartao
    {
        [XmlAttribute()]
        public string Numero { get; set; }        
        [XmlAttribute()]
        public bool Selecionado { get; set; }
    }

    [Serializable()]
    public sealed class Compra
    {
        [XmlAttribute()]
        public double Valor { get; set; }
        [XmlAttribute()]
        public DateTime Data { get; set; }
        [XmlAttribute()]
        public string Local { get; set; }
    }

    [Serializable()]
    public sealed class VisaSaldo
    {
        [XmlElement()]
        public NumeroCartao NumeroCartao { get; set; }
        [XmlAttribute()]
        public double SaldoDisponivel { get; set; }
        [XmlAttribute()]
        public DateTime UltimoDeposito { get; set; }
        [XmlElement()]
        public Compra ProximoDeposito { get; set; }
        [XmlElement()]
        public List<Compra> Compras { get; set; }
        [XmlElement()]
        public List<Compra> Creditos { get; set; }
    }

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                object arquivo = e.Data.GetData(DataFormats.FileDrop);
                if (arquivo.GetType().Name.ToLower() == "string[]")
                {
                    string[] arquivos = (string[])arquivo;
                    if (arquivos.Count() > 0)
                    {
                        string arq1 = arquivos[0];
                        const string c_pwd = "Mamamia, here we go again! Mama! Mamamia!";
                        XmlSerializer xml = new XmlSerializer(typeof(List<VisaSaldo>));
                        List<VisaSaldo> saldos = null;
                        using (FileStream f = File.Open(arq1, FileMode.Open))
                        {
                            System.Security.Cryptography.Rijndael enc = System.Security.Cryptography.RijndaelManaged.Create();
                            System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
                            enc.Key = md5.ComputeHash(Encoding.ASCII.GetBytes(c_pwd));
                            enc.IV = md5.ComputeHash(Encoding.ASCII.GetBytes(c_pwd));
                            using (System.Security.Cryptography.CryptoStream encStream = new System.Security.Cryptography.CryptoStream(f, enc.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Read))
                            {
                                try
                                {
                                    saldos = (List<VisaSaldo>)xml.Deserialize(encStream);
                                }
                                catch (Exception)
                                {
                                    //
                                }
                                finally
                                {
                                    f.Close();
                                }
                            }
                            if (saldos != null)
                            {
                                string[] caminhoBase = arq1.Split('\\');
                                caminhoBase[caminhoBase.Count() - 1] = caminhoBase[caminhoBase.Count() - 1] + ".db";
                                string caminhoOk = String.Join("\\", caminhoBase);
                                SQLiteConnection cnx = new SQLiteConnection("Data Source=" + caminhoOk);
                                cnx.Open();
                                SQLiteCommand cmd = cnx.CreateCommand();
                                cmd.CommandText = @"create table if not exists cartao (
                                              numero varchar(16) primary key,
                                              descricao varchar (35),
                                              saldo numeric(6, 2) default 0)";
                                cmd.ExecuteNonQuery();
                                cmd.CommandText = @"create table if not exists beneficio (
                                       seq integer primary key autoincrement,
                                       numero varchar(16) not null references cartao(numero) on delete cascade,
                                       data date,
                                       valor numeric(6, 2))";
                                cmd.ExecuteNonQuery();
                                cmd.CommandText = @"create table if not exists proximoBeneficio (
                                       seq integer primary key autoincrement,
                                       numero varchar(16) not null references cartao(numero) on delete cascade,
                                       data date,
                                       valor numeric(6, 2))";
                                cmd.ExecuteNonQuery();
                                cmd.CommandText = @"create table if not exists compra (
                                       numero varchar(16) not null references cartao(numero) on delete cascade,
                                       idCompra integer primary key autoincrement,
                                       local varchar(50),
                                       valor numeric(6, 2),
                                       data date)";
                                cmd.ExecuteNonQuery();
                                cmd.CommandText = "create unique index if not exists beneficio_idx on beneficio(numero, data, valor)";
                                cmd.ExecuteNonQuery();
                                cmd.CommandText = "create unique index if not exists proxBeneficio_idx on proximoBeneficio (numero, data, valor)";
                                cmd.ExecuteNonQuery();
                                cmd.CommandText = "create unique index if not exists compra_idx on compra(numero, local, valor, data)";
                                cmd.ExecuteNonQuery();
                                foreach (VisaSaldo saldo in saldos)
                                {
                                    cmd.CommandText = "insert into cartao(numero, descricao, saldo) values(@numero, null, @saldo)";
                                    cmd.Parameters.AddWithValue("@numero", saldo.NumeroCartao.Numero);
                                    cmd.Parameters.AddWithValue("@saldo", saldo.SaldoDisponivel);
                                    cmd.ExecuteNonQuery();
                                    foreach (Compra compra in saldo.Compras)
                                    {
                                        cmd.CommandText = "insert into compra(numero, local, valor, data) values (@numero, @local, @valor, @data)";
                                        cmd.Parameters.AddWithValue("@numero", saldo.NumeroCartao.Numero);
                                        cmd.Parameters.AddWithValue("@local", compra.Local);
                                        cmd.Parameters.AddWithValue("@valor", compra.Valor);
                                        cmd.Parameters.AddWithValue("@data", compra.Data);
                                        try
                                        {
                                            cmd.ExecuteNonQuery();
                                        }
                                        catch
                                        {
                                            //
                                        }
                                    }
                                    foreach (Compra benef in saldo.Creditos)
                                    {
                                        cmd.CommandText = "insert into beneficio(numero, valor, data) values (@numero, @valor, @data)";
                                        cmd.Parameters.AddWithValue("@numero", saldo.NumeroCartao.Numero);
                                        cmd.Parameters.AddWithValue("@valor", benef.Valor);
                                        cmd.Parameters.AddWithValue("@data", benef.Data);
                                        cmd.ExecuteNonQuery();
                                    }
                                    if (saldo.ProximoDeposito != null)
                                    {
                                        cmd.CommandText = "insert into proximoBeneficio (numero, valor, data) values (@numero, @valor, @data)";
                                        cmd.Parameters.AddWithValue("@numero", saldo.NumeroCartao.Numero);
                                        cmd.Parameters.AddWithValue("@valor", saldo.ProximoDeposito.Valor);
                                        cmd.Parameters.AddWithValue("@data", saldo.ProximoDeposito.Data);
                                        cmd.ExecuteNonQuery();
                                    }
                                }
                            }
                        }
                    }
                }                
            }
        }
    }
}
